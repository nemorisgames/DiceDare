//
//  MPTableViewAdPlacerCell.h
//  MoPubSDK
//
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPTableViewAdPlacerCell : UITableViewCell

@end
